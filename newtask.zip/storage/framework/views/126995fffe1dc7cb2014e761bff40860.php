















<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?>
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>



    <?php if(Route::has('login')): ?>
        <div>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">Log in</a>

                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>">Register</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    <div><a href="<?php echo e(route('groups.index')); ?>">groups</a></div>
    <div><a href="<?php echo e(route('home')); ?>">tasks</a></div>




    <?php
        $CurentTime = now();
    ?>

    <div style="width: 80%;margin: auto;">
        <div style="display: flex;flex-direction: row;justify-content: start;align-items: center;border: 1px dashed silver;padding: 10px;height:60px;border-radius: 25px;margin: 10px;text-align: center;background-color: white;box-shadow: 0px 0px 5px silver;">
            <a href="<?php echo e(route('tasks.create')); ?>"> <span class="icon-plus"></span> add new task</a>
        </div>
        <div style="display: flex;flex-direction: row;justify-content: start;align-items: center;border: 1px dashed silver;padding: 10px;height:60px;border-radius: 25px;margin: 10px;text-align: center;background-color: white;box-shadow: 0px 0px 5px silver;">
            <div style="flex: 16;text-align: left;">name</div>
            <div style="flex: 3">finish at</div>
            <div style="flex: 1;padding: 0 5px;border-radius: 5px;min-width: 10%;">status</div>
            <div style="flex: 1;"></div>
            <div style="flex: 3;display: flex;justify-content: center;align-items: center;">progress</div>
            <div style="flex: 1;text-align: end;display: flex;align-items: flex-start;"></div>
            <div style="flex:1">group</div>
            <div style="flex:1">detail</div>
        </div>

        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div  x-data="{ open: false }" >
                <div style="position: relative;z-index: 1;display: flex;flex-direction: row;justify-content: space-between;align-items: center;border: 1px solid silver;padding: 10px;border-radius: 25px;margin: 10px;text-align: center;height: 60px;background-color: white;box-shadow: 0px 0px 5px silver;">
                    <div style="flex: 16;text-align: left;"><?php echo e($task->subject); ?></div>
                    <div style="flex: 3">
                        <small><?php echo e(\Carbon\Carbon::parse($task->deadline)->toFormattedDateString()); ?></small>
                    </div>
                    <div class="<?php echo e($task->status); ?>" style="flex: 1;padding: 0 5px;border-radius: 5px;color: white;min-width: 10%;">
                        <?php echo e($task->status); ?>

                    </div>
                    <div style="flex: 1;">
                        <?php if($task->status == 'inprogress' && !is_null(Auth::user())): ?>
                            <?php
                                $lastStatusForTask = null;
                                foreach($timesForCurrentUser as $time) {
                                    if($time->task_id == $task->id) {
                                        $lastStatusForTask = $time->status;
                                    }
                                }
                            ?>
                            <?php if($lastStatusForTask): ?>
                                <form action="<?php echo e(route('times.update', $task->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <input type="hidden" name="task_id" value="<?php echo e($task->id); ?>">
                                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                    <input type="hidden" name="end" value="<?php echo e($CurentTime); ?>">
                                    <button type="submit" class="pausbtn"><span style="font-size: x-large;" class="icon-controller-paus"></span></button>
                                </form>
                            <?php elseif(!$lastStatusForTask): ?>
                                <form action="<?php echo e(route('times.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="task_id" value="<?php echo e($task->id); ?>">
                                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                    <input type="hidden" name="start" value="<?php echo e($CurentTime); ?>">
                                    <button type="submit" class="startbtn"><span style="font-size: x-large;" class="icon-controller-play"></span></button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div style="flex: 3;display: flex;justify-content: center;align-items: center;">
                        <?php
                            if (!empty($task->times) && isset($task->times[0])) {
                                $firstStart = $task->times[0]->start;
                                $dead = $task->deadline;
                                $start = \Carbon\Carbon::parse($firstStart);
                                $end = \Carbon\Carbon::parse($dead);
                                $all = $end->diffInMinutes($start);
                            } else {
                                $firstStart = 0;
                                $all = 0;
                            }
                            $sum = 0;
                            foreach($task->times as $time){
                                $sum += $time->diffMinute;
                            }
                            if($all !=0){
                                $progress = ($sum/$all)*100;
                                $progress = round($progress);
                            }else{
                                $progress = null;
                            }
                        ?>
                        <?php if($task->status == 'inprogress' || $task->status == 'done'): ?>

                                <svg width="40" height="40" viewBox="0 0 250 250" class="circular-progress" style="--progress: <?php echo e($progress); ?>">
                                    <circle class="bg"></circle>
                                    <circle class="fg"></circle>
                                </svg>
                                <small> <?php echo e($progress); ?>%</small>

                        <?php endif; ?>
                    </div>
                    <div style="flex: 1;text-align: end;display: flex;align-items: flex-start;">
                        <?php if($task->groups->count() > 0 ): ?>

                            <?php $__currentLoopData = $task->groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="icon-shield tooltip" >
                                    <span class="tooltiptext">
                                <?php $__currentLoopData = $group->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($user->pivot->role === 'supervisor'): ?>
                                        <?php echo e($user->name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </span>
                                </span>

                                <small style="color: white;font-size: 9px;background-color: #939393;padding: 2px;border-radius: 50%;">
                                    +<?php echo e($task->groups->count()); ?>

                                </small>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div style="flex: 1;">
                        <a href="<?php echo e(route('showGroupTaskForm', $task)); ?>"><span class="icon-flow-tree"></span></a>
                    </div>
                    <div style="flex:1">
                        <span class="icon-dots-three-vertical"  x-on:click="open = ! open"></span>
                    </div>
                </div>
                <div x-show="open" style="width: 86%;margin: -10px auto 10px;background-color: white;position: relative;z-index: 0;padding: 13px;border-bottom-left-radius: 20px;border-bottom-right-radius: 20px;border: 1px solid #e7e7e7;">
                    <div style="text-align: center;"><?php echo e($task->description); ?></div>
                    <div style="display: flex;justify-content: space-evenly;flex-direction: row;">
                        <div>
                            <form action="<?php echo e(route('tasks.update', $task->id)); ?>" method="post" onsubmit="return confirm('are you sure?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="text" value="done" name="status" hidden />
                                <button type="submit">is it done <span class="icon-thunder-cloud"></span></button>
                            </form>
                        </div>
                        <div>
                            <form action="<?php echo e(route('tasks.update', $task->id)); ?>" method="post" onsubmit="return confirm('are you sure?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="text" value="fail" name="status" hidden />
                                <button type="submit">is it fail <span class="icon-new"></span></button>
                            </form>
                        </div>
                        <div>
                            <form action="<?php echo e(route('tasks.destroy', $task->id)); ?>" method="post" onsubmit="return confirm('are you sure?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit">delete task <span class="icon-trash"></span></button>
                            </form>
                        </div>
                        <div>
                            <form action="<?php echo e(route('tasks.update', $task->id)); ?>" method="post" onsubmit="return confirm('are you sure?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="datetime-local" name="deadline">
                                <button type="submit">take overtime <span class="icon-battery"></span></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if(session('success')): ?>
        <div id="alert" class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div id="alert" class="alert alert-error">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <script>
        setTimeout(function() {
            var div = document.getElementById("alert");
            div.parentNode.removeChild(div);
        }, 4000);
    </script>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>


<?php /**PATH C:\Users\zarabi\Desktop\newtask\resources\views/tasksview.blade.php ENDPATH**/ ?>
