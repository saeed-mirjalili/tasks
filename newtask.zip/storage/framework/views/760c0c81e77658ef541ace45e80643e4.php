












<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <link href="/css/style.css" rel="stylesheet" />
        <link href="/css/index.css" rel="stylesheet" />
        <link href="/css/tree.css" rel="stylesheet" />
<div style="
    display: flex;
    justify-content: space-evenly;
    align-items: center;
    width: 80%;
    margin: 10px auto;
    ">
    <div style="width: 30%;
    background-color: white;
    padding: 30px;
    border-radius: 16px;
    box-shadow: 0 3px 6px #d5d5d5;
    ">
        <form method="POST" action="<?php echo e(route('addUserTask')); ?>">
            <?php echo csrf_field(); ?>
            <input type="text" name="group" value="<?php echo e($group->id); ?>" hidden>
            <select id="users" name="user"  style="border: 1px solid silver;border-radius: 10px;margin: 5px;">
                <option value="" disabled selected>pleas select a user</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="isSupervisor" class="inline-flex items-center" style="margin: 5px;">
                <input id="remember_me" type="checkbox" class="rounded dark:bg-gray-900 border-gray-300 dark:border-gray-700 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800" name="isSupervisor">
                <span class="ms-2 text-sm text-gray-600 dark:text-gray-400"><?php echo e(__('Is Supervisor')); ?></span>
            </label>
            <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'ms-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ms-3']); ?>
                <span class="icon-login"></span><?php echo e(__('Add')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
        </form>
    </div>


    <div style="width: 30%;
    background-color: white;
    padding: 30px;
    border-radius: 16px;
    box-shadow: 0 3px 6px #d5d5d5;">
        <form method="post" action="<?php echo e(route('removeUserTask')); ?>">
            <?php echo csrf_field(); ?>
            <input type="text" name="group" value="<?php echo e($group->id); ?>" hidden>

            <select id="users" name="user"  style="border: 1px solid silver;border-radius: 10px;margin: 5px;">
                <option value="" disabled selected>pleas select a user</option>
                <?php $__currentLoopData = $groupUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($groupUser->id); ?>"><?php echo e($groupUser->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'ms-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ms-3']); ?>
                <?php echo e(__('Remove')); ?><span class="icon-log-out"></span>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>

        </form>
    </div>
</div>


<div style="width: 80%;
    background-color: white;
    padding: 30px;
    border-radius: 16px;
    box-shadow: 0 3px 6px #d5d5d5;
    margin: auto;
    ">
    <div class="tree">
        <ul>
            <li>
                <?php $__currentLoopData = $groupUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($taskUser->role == 'supervisor'): ?>
                        <a href="#"><?php echo e($taskUser->name); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <ul>
                    <?php $__currentLoopData = $taskUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taskUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($taskUser->role == 'user'): ?>
                            <li>
                                <a href="#"><?php echo e($taskUser->name); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

            </li>
        </ul>
    </div>
</div>


<?php if(session('success')): ?>
    <div id="alert" class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div id="alert" class="alert alert-error">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<script>
    setTimeout(function() {
        var div = document.getElementById("alert");
        div.parentNode.removeChild(div);
    }, 4000);
</script>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>




<?php /**PATH C:\Users\zarabi\Desktop\newtask\resources\views/groupsTaskForm.blade.php ENDPATH**/ ?>
