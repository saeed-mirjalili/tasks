
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Groups')); ?>

        </h2>
     <?php $__env->endSlot(); ?>



<?php
    $CurentTime = now();
?>

<div style="width: 80%;margin: auto;">
    <div style="display: flex;flex-direction: row;justify-content: start;align-items: center;border: 1px dashed silver;padding: 10px;border-radius: 25px;margin: 10px;text-align: center;height: 60px;background-color: white;box-shadow: 0px 0px 5px silver;">
        <a href="<?php echo e(route('groups.create')); ?>"> <span class="icon-plus"></span> add new group</a>
    </div>
    <div style="display: flex;flex-direction: row;justify-content: start;align-items: center;border: 1px dashed silver;padding: 10px;border-radius: 25px;margin: 10px;text-align: center;height: 60px;background-color: white;box-shadow: 0px 0px 5px silver;">
        <div style="flex: 16;text-align: left;">name</div>
        <div style="flex: 3">create at</div>
        <div style="flex: 1;padding: 0 5px;border-radius: 5px;min-width: 10%;">rate</div>
        <div style="flex: 1;"></div>
        <div style="flex: 3;display: flex;justify-content: center;align-items: center;">users</div>
        <div style="flex: 1;text-align: end;display: flex;align-items: flex-start;"></div>
        <div style="flex:1">tasks</div>
        <div style="flex:1">detail</div>
    </div>

    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div  x-data="{ open: false }" >
            <div style="position: relative;z-index: 1;display: flex;flex-direction: row;justify-content: space-between;align-items: center;border: 1px solid silver;padding: 10px;border-radius: 25px;margin: 10px;text-align: center;height: 60px;background-color: white;box-shadow: 0px 0px 5px silver;">
                <div style="flex: 16;text-align: left;"><?php echo e($group->name); ?></div>
                <div style="flex: 3">
                    <small><?php echo e(\Carbon\Carbon::parse($group->created_at)->toFormattedDateString()); ?></small>
                </div>
                <div style="flex: 1;padding: 0 5px;border-radius: 5px;min-width: 10%;display: flex;justify-content: center;color: #dfbc01;">
                    <?php for($i = 0 ; $i < 5; $i++): ?>
                        <?php if($i < $group->rate): ?>
                            <span class="icon-star"></span>
                        <?php else: ?>
                            <span class="icon-star-outlined"></span>
                        <?php endif; ?>
                    <?php endfor; ?>
                </div>
                <div style="flex: 1;">

                </div>
                <div style="flex: 3;display: flex;justify-content: center;align-items: center;">
                    <?php echo e($group->users->count()); ?>

                </div>
                <div style="flex: 1;text-align: end;display: flex;align-items: flex-start;">

                </div>
                <div style="flex: 1;">
                    <?php echo e($group->tasks->count()); ?>

                </div>
                <div  style="flex: 1;">
                    <a href="<?php echo e(route('showUserGroupForm', $group->id )); ?>"><span class="icon-flow-tree"></span></a>
                </div>
                <div style="flex:1">
                    <span class="icon-dots-three-vertical"  x-on:click="open = ! open"></span>
                </div>
            </div>
            <div x-show="open" style="width: 86%;margin: -10px auto 10px;background-color: white;position: relative;z-index: 0;padding: 13px;border-bottom-left-radius: 20px;border-bottom-right-radius: 20px;border: 1px solid #e7e7e7;">
                <div style="text-align: center;"></div>
                <div style="display: flex;justify-content: space-evenly;flex-direction: row;">
                    <div>
                        done task:<?php echo e($taskCounts[$group->id]['successful'] ?? 0); ?><span class="icon-thumbs-up"></span>
                        failed task:<?php echo e($taskCounts[$group->id]['unsuccessful'] ??  0); ?><span class="icon-thumbs-down"></span>
                    </div>
                    <div>






                    </div>
                    <div>





                    </div>
                    <div>






                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php if(session('success')): ?>
    <div id="alert" class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div id="alert" class="alert alert-error">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<script>
    setTimeout(function() {
        var div = document.getElementById("alert");
        div.parentNode.removeChild(div);
    }, 4000);
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>




<?php /**PATH C:\Users\zarabi\Desktop\newtask\resources\views/groupsview.blade.php ENDPATH**/ ?>