<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php
        $CurentTime = now();
    ?>
    <div style="width: 80%;margin: auto;">

        <div style="display: flex;flex-direction: row;justify-content: start;align-items: center;border: 1px dashed silver;padding: 10px;height:60px;border-radius: 25px;margin: 10px;text-align: center;background-color: white;box-shadow: 0px 0px 5px silver;">
            <div style="flex: 16;text-align: left;">name</div>
            <div style="flex: 3">finish at</div>
            <div style="flex: 1;padding: 0 5px;border-radius: 5px;min-width: 10%;">status</div>
            <div style="flex: 1;">run</div>
            <div style="flex:1">detail</div>
        </div>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div  x-data="{ open: false }" >
                <div style="position: relative;z-index: 1;display: flex;flex-direction: row;justify-content: space-between;align-items: center;border: 1px solid silver;padding: 10px;border-radius: 25px;margin: 10px;text-align: center;height: 60px;background-color: white;box-shadow: 0px 0px 5px silver;">
                    <div style="flex: 16;text-align: left;"><?php echo e($task->subject); ?></div>
                    <div style="flex: 3">
                        <small><?php echo e(\Carbon\Carbon::parse($task->deadline)->toFormattedDateString()); ?></small>
                    </div>
                    <div class="<?php echo e($task->status); ?>" style="flex: 1;padding: 0 5px;border-radius: 5px;color: white;min-width: 10%;">
                        <?php echo e($task->status); ?>

                    </div>
                    <div style="flex: 1;">
                        <?php if($task->status == 'inprogress' && !is_null(Auth::user())): ?>
                            <?php
                                $lastStatusForTask = null;
                            ?>
                            <?php $__currentLoopData = $timesForCurrentUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($time->task_id == $task->id): ?>
                                    <?php
                                        $lastStatusForTask = $time->status;
                                    ?>
                                <?php endif; ?>
                                <?php if(is_null($time)): ?>
                                    <?php
                                        $lastStatusForTask = false;
                                    ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if($lastStatusForTask): ?>
                                <form action="<?php echo e(route('times.update', $task->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <input type="hidden" name="task_id" value="<?php echo e($task->id); ?>">
                                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                    <input type="hidden" name="end" value="<?php echo e($CurentTime); ?>">
                                    <button type="submit" class="pausbtn"><span style="font-size: x-large;" class="icon-controller-paus"></span></button>
                                </form>
                            <?php elseif(!$lastStatusForTask): ?>
                                <form action="<?php echo e(route('times.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="task_id" value="<?php echo e($task->id); ?>">
                                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                    <input type="hidden" name="start" value="<?php echo e($CurentTime); ?>">
                                    <button type="submit" class="startbtn"><span style="font-size: x-large;" class="icon-controller-play"></span></button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>

                    </div>
                    <div style="flex:1">
                        <span class="icon-dots-three-vertical"  x-on:click="open = ! open"></span>
                    </div>
                </div>
                <div x-show="open" style="width: 86%;margin: -10px auto 10px;background-color: white;position: relative;z-index: 0;padding: 13px;border-bottom-left-radius: 20px;border-bottom-right-radius: 20px;border: 1px solid #e7e7e7;">
                    <div style="text-align: center;"><?php echo e($task->description); ?></div>
                    <div style="display: flex;justify-content: space-evenly;flex-direction: row;">
                        <div>
                            <table>
                                <tr>

                                    <th>start at</th>
                                    <th>end at</th>
                                    <th>duration</th>
                                </tr>

                                <?php if(!is_null($timesForCurrentUser)): ?>
                                    <?php $__currentLoopData = $timesForCurrentUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                            <td><?php echo e($time->start); ?></td>
                                            <td><?php echo e($time->end); ?></td>
                                            <td><?php echo e($time->diffMinute); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if(session('success')): ?>
        <div id="alert" class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div id="alert" class="alert alert-error">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <script>
        setTimeout(function() {
            var div = document.getElementById("alert");
            div.parentNode.removeChild(div);
        }, 4000);
    </script>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\zarabi\Desktop\newtask\resources\views/dashboard.blade.php ENDPATH**/ ?>